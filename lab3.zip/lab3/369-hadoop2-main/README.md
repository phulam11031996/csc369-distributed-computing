# 369-hadoop2
Hadoop Example 2 (reduce-side join example)
